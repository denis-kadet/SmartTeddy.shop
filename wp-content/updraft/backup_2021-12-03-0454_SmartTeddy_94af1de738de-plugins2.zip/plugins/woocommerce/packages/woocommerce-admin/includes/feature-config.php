<?php
// WARNING: Do not directly edit this file.
// This file is auto-generated as part of the build process and things may break.
if ( ! function_exists( 'wc_admin_get_feature_config' ) ) {
	function wc_admin_get_feature_config() {
		return array(
			'activity-panels' => true,
			'analytics' => true,
			'coupons' => true,
			'customer-effort-score-tracks' => true,
			'homescreen' => true,
			'marketing' => true,
			'minified-js' => false,
			'mobile-app-banner' => true,
			'navigation' => false,
			'onboarding' => true,
			'remote-inbox-notifications' => true,
			'remote-free-extensions' => true,
			'payment-gateway-suggestions' => true,
			'settings' => false,
			'shipping-label-banner' => true,
			'subscriptions' => true,
			'store-alerts' => true,
			'tasks' => false,
			'transient-notices' => true,
			'wc-pay-promotion' => true,
		);
	}
}
