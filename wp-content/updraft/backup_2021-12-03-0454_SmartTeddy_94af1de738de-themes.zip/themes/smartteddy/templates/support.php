<?php
/*
Template Name: Support
*/
?>
<?get_header();?>
<main class="main">
<section class="section support__section">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-lg-4  col-sm-8 col-8">
                <div class="support__contacts">
                    <a href="tel:+79295065403" class="support__tel">(929) 506 5403</a>
                    <div class="support__contact-desc">Monday to Friday 9 am - 5 pm EST</div>
                    <a href="mailto:hello@smartteddy.store" class="support__email">hello@smartteddy.store</a>
                    <span class="support__contact-arrows"></span>
                </div>

            </div>
            <div class="col-lg-4 col-lg-4 col-sm-4 col-4">
                <div class="support__img-wrap">
                    <img class="support__img" src="<?php echo get_template_directory_uri(); ?>/assets/images/icons/support-bear.svg" alt="">
                </div>
            </div>
            <div class="col-lg-8 col-lg-8  col-sm-12 col-12">
                <?php echo do_shortcode('[contact-form-7 id="27" title="Subscribe"]'); ?>
            </div>
        </div>
    </div>

</section>
    <section class="support__section support__section-1">
        <div class="container support__bg">
            <div class="row support__bg-mob">
                <div class="col-lg-12">
                    <h3 class="support__title">
                        Frequently asked questions
                    </h3>
                    <ul id="my-accordion" class="accordionjs">
                        <!-- Section 1 -->
                        <li>
                            <h4 class="accordion__title">How do I set up Smart Teddy?</h4>
                            <ul class="accordion__items">
                                <li class="accordion__item">Turn on your Teddy.</li>
                                <li class="accordion__item">Download My Smart Teddy app for iOS from the App Store or for Android from Google Play, turn on your Bluetooth and grant permission to use geolocation.</li>
                                <li class="accordion__item">Complete your registration in the app: enter your telephone number and the verification code that was texted to you or log in using your Google or Facebook account.</li>
                                <li class="accordion__item"> Find your Teddy in the application. In order to synchronize it, you will have to press both bottom paws at the same time when the application asks you to.</li>
                                <li class="accordion__item"> If you cannot connect to your Teddy, he may already be synchronized with another smartphone.
                                </li>
                                <li class="accordion__item"> Deactivate the existing connection and try to connect again.
                                </li>
                            </ul>
                        </li>
                        <!-- Section 2 -->
                        <li>
                            <h3 class="accordion__title">How safe is Smart Teddy?</h3>
                            <ul class="accordion__items">
                                <li class="accordion__item">We are confident that the Smart Teddy will be one of the safest devices for children you have in your home. Teddy has been tested for safety and has received an FCC certificate.</li>
                                <li class="accordion__item">The internal module is made of impact-resistant plastic. We have sewn the module into the toy to prevent a child from taking it out, and the wires are hidden. This toy does not contain any built-in cameras or mic and does not collect or transmit information about children.</li>
                                <li class="accordion__item">The Teddy also has MSDS and UN safety certificates for the battery and an ASTM certificate for the toy itself. </li>
                            </ul>
                        </li>
                        <!-- Section 3 -->
                        <li>
                            <h3 class="accordion__title">Why does Smart Teddy need a mobile app?</h3>
                            <ul class="accordion__items">
                                <li class="accordion__item">The app was created for parents to help them control the toy and its content, like games, lessons, and the Favorites section. The app can also connect the Teddy to a home Wi-Fi network so it can download updates.</li>
                            </ul>
                        </li>
                        <!-- Section 4 -->
                        <li>
                            <h3 class="accordion__title">What is your return policy?</h3>
                            <ul class="accordion__items">
                                <li class="accordion__item">You have thirty days to return your Teddy for a full refund if he doesn't fit you family, but also we have 12-month of the extended warranty. Just send us an email at:
                                    <a href="mailto:hello@smartteddy.store">hello@smartteddy.store</a></li>
                            </ul>
                        </li>
                        <!-- Section 5 -->
                        <li>
                            <h3 class="accordion__title">What can the Smart Teddy do?</h3>
                            <ul class="accordion__items">
                                <li class="accordion__item">The application contains 25+ fully-realized scripts: brushing your teeth, taking a bath in the evening, washing your hands, outdoor gatherings, getting up, good manners, daydreaming, and when it's time to stop watching cartoons. </li>
                                <li class="accordion__item">In order to make the learning process more interesting and more effective, Teddy tells riddles and looks for the right answer along with the kid, also he helps them learn ABCs, Numbers, and lots of fun facts!</li>
                            </ul>
                        </li>
                        <!-- Section 6 -->
                        <li>
                            <h3 class="accordion__title">How many stories does Smart Teddy know?</h3>
                            <ul class="accordion__items">
                                <li class="accordion__item">Smart Teddy has 28 pieces in the library —a week's worth of fairytales for both daytime and nighttime. There are 3 daytime stories and one bedtime story a day. They repeat every seven days.</li>
                                <li class="accordion__item">Smart Teddy has a whole library of fairytales in his head, filled with all kinds of stories: folklore, classics from around the world, and pieces by well-known contemporary authors. These educational scripts are constantly being improved and will be updated.</li>
                                <li class="accordion__item">All the stories are chosen carefully, and some of them have accompanying explanations; our users say that the Smart Teddy helps children think things through and draw conclusions from what they hear.</li>
                            </ul>
                        </li>

                    </ul>
                </div>
                <div class="col-lg-12">
                    <h3 class="support__title">
                        Smart Teddy
                    </h3>
                    <ul id="my-accordion-1" class="accordionjs">
                        <!-- Section 1 -->
                        <li>
                            <h4 class="accordion__title">Who is Smart Teddy?</h4>
                            <ul class="accordion__items">
                                <li class="accordion__item">Smart Teddy is a multifunctional AI companion for kids ages 3-6, specially designed to get them away from the TV and off their tablets. How? The Teddy comes loaded with a specially selected playlist of fairytales, poems, and stories for every day, and he can tell them with consummate artistry. The Teddy also helps kids to develop life skills and motivates them to take care of everyday responsibilities they aren't always excited about (like brushing their teeth or picking up their toys), plus he can teach them their ABCs and 123s, solve riddles, talk about the weather, and much more. Parents can use a smartphone to control the toy and manage all uploaded content.</li>
                            </ul>
                        </li>
                        <!-- Section 2 -->
                        <li>
                            <h3 class="accordion__title">What's the recommended age for the Teddy?</h3>
                            <ul class="accordion__items">
                                <li class="accordion__item">All of the content has been developed and approved by psychologists and education experts for children ages 3-6. This recommended age range is flexible, though, and Teddy counts both younger users and kids that are a little older among his friends.</li>
                            </ul>
                        </li>
                        <!-- Section 3 -->
                        <li>
                            <h3 class="accordion__title">How is he built?</h3>
                            <ul class="accordion__items">
                                <li class="accordion__item">The Teddy has an electronics package inside, including Bluetooth, Wi-Fi, and NFC modules, a memory card, and a battery.</li>
                            </ul>
                        </li>
                        <!-- Section 4 -->
                        <li>
                            <h3 class="accordion__title">How do I control him?</h3>
                            <ul class="accordion__items">
                                <li class="accordion__item">The Teddy can be controlled using the buttons on his paws as well as the mobile app. You can use the app to make the toy encourage kids to do something—wash their hands, pick up their toys, say the "magic word," and much more. Functions like teaching numbers and the alphabet or playing riddles and fairytales are also controlled through the app interface.</li>
                            </ul>
                        </li>
                        <!-- Section 5 -->
                        <li>
                            <h3 class="accordion__title">What does the set include?</h3>
                            <ul class="accordion__items">
                                <li class="accordion__item">In addition to the toy itself, you will get a charger, a manual (which is also available through the mobile app), and a set of four stickers. On contact with Teddy's paw, each sticker automatically launches a preprogrammed action, like giving a detailed walkthrough of how to brush your teeth (bathroom sticker) or telling a bedtime story (crib sticker).</li>
                            </ul>
                        </li>
                        <!-- Section 6 -->
                        <li>
                            <h3 class="accordion__title">How big is he and how much does he weigh?</h3>
                            <ul class="accordion__items">
                                <li class="accordion__item">The Teddy was designed so kids can give him hugs and take him with them everywhere! He weighs a little over a pound, and his height is about 10 inches.</li>
                            </ul>
                        </li>
                        <!-- Section 7 -->
                        <li>
                            <h3 class="accordion__title">What lessons does the Teddy know?!</h3>
                            <ul class="accordion__items">
                                <li class="accordion__item">Teddy knows how to play in a way that simultaneously fosters learning and development. This toy will help children learn numbers and the alphabet. All of this content has been developed by professional educators and psychologists, so you can rest assured that your child will never hear anything untoward from their Teddy. </li>
                            </ul>
                        </li>

                    </ul>
                </div>
                <div class="col-lg-12">
                    <h3 class="support__title">
                        Payment and delivery
                    </h3>
                    <ul id="my-accordion-2" class="accordionjs">
                        <!-- Section 1 -->
                        <li>
                            <h4 class="accordion__title">What forms of payment do you accept? </h4>
                            <ul class="accordion__items">
                                <li class="accordion__item">You can pay for your order online using a bank card.</li>
                            </ul>
                        </li>
                        <!-- Section 2 -->
                        <li>
                            <h3 class="accordion__title">Can you deliver a Teddy anywhere?</h3>
                            <ul class="accordion__items">
                                <li class="accordion__item">At this moment we can ship Teddies anywhere in the U.S. via UPS. You can check Smart Teddy on Amazon for an extended delivery option.</li>
                            </ul>
                        </li>
                        <!-- Section 3 -->
                        <li>
                            <h3 class="accordion__title">What delivery options do you offer?</h3>
                            <ul class="accordion__items">
                                <li class="accordion__item">We have free Standard shipping, which will take 3-5 business days, and UPS priority shipping, 2-3 business days for an extra $10.</li>
                            </ul>
                        </li>
                    </ul>
                </div>
                <div class="col-lg-12">
                    <h3 class="support__title">
                        Technical questions
                    </h3>
                    <ul id="my-accordion-3" class="accordionjs">
                        <!-- Section 1 -->
                        <li>
                            <h4 class="accordion__title">How do I download the app?</h4>
                            <ul class="accordion__items">
                                <li class="accordion__item">The app is available for download from the App Store and PlayMarket. Just type "Smart Teddy" in the store search bar, then download the app and follow the instructions. Note that there may be issues when using the app on the latest models of Huawei and Honor smartphones that have AppGallery preinstalled instead of PlayMarket. If that happens, we recommend that you use a smartphone from another manufacturer.</li>
                            </ul>
                        </li>
                        <!-- Section 2 -->
                        <li>
                            <h3 class="accordion__title">Why does Teddy need to use Bluetooth?</h3>
                            <ul class="accordion__items">
                                <li class="accordion__item">Bluetooth is only used to connect to the application and interact with downloaded content. All updates are performed using a safer and more secure Wi-Fi connection. </li>
                            </ul>
                        </li>
                        <!-- Section 3 -->
                        <li>
                            <h3 class="accordion__title">How does the update himself?</h3>
                            <ul class="accordion__items">
                                <li class="accordion__item">TAlthough he has a Wi-Fi module, the Teddy is not constantly connected to your network. In order to receive updates, you can connect the toy to your home Wi-Fi network using the application. The Teddy will check for available updates and download them if he finds any. That means he can automatically update himself at night—all you have to do is leave the toy fully powered on.</li>
                            </ul>
                        </li>
                        <!-- Section 4 -->
                        <li>
                            <h3 class="accordion__title">If updates come out after we buy our Teddy, will we get them?</h3>
                            <ul class="accordion__items">
                                <li class="accordion__item">All of Teddy's updates and new skills will be downloaded automatically as soon as they come out. There will also be themed updates; for example, when the holiday season rolls around, the Teddy can wish kids a Merry Christmas, tell them stories about wintertime, and offer special riddles for the new year.</li>
                            </ul>
                        </li>
                        <!-- Section 5 -->
                        <li>
                            <h3 class="accordion__title">Initial startup and activation</h3>
                            <ul class="accordion__items">
                                <li class="accordion__item">Turn on your Teddy.</li>
                                <li class="accordion__item">Download My Smart Teddy iOS application from the App Store or the Android application from Google Play, then turn your Bluetooth on. If your phone uses Android, the application with a request that you activate geolocation. Beginning with Android 6.0, Google will require access to your location, otherwise, it will be impossible to control Smart Teddy through the app.</li>
                                <li class="accordion__item">Complete your registration in the app: enter your telephone number and the verification code that was texted to you or log in using your Google or Facebook account.</li>
                                <li class="accordion__item">Find your Smart Teddy in the application. In order to synchronize it, you will have to press both bottom paws at the same time when the application asks you to.</li>
                                <li class="accordion__item">After your Smart Teddy has successfully connected, press the "Settings" button, find the Wi-Fi tab, connect to your network, and wait until the "Smart Teddy is Updating" message disappears.</li>
                            </ul>
                        </li>
                        <!-- Section 6 -->
                        <li>
                            <h3 class="accordion__title">Does the Teddy have an On/Off button? Can you turn him off completely?</h3>
                            <ul class="accordion__items">
                                <li class="accordion__item">Of course! </li>
                                <li class="accordion__item">There is a switch on the box inside the Smart Teddy: Off mode (fully deactivated). The toy is turned on, but Bluetooth and Wi-Fi are not active—you can use the toy but he won't connect update itself or connect to your phone.</li>
                                <li class="accordion__item">On mode—the Smart Teddy is turned on, and both Bluetooth and Wi-Fi are active.</li>
                            </ul>
                        </li>
                        <!-- Section 7 -->
                        <li>
                            <h3 class="accordion__title">Where can I download the Smart Teddy mobile app?</h3>
                            <ul class="accordion__items">
                                <li class="accordion__item">The app is available for iOS on the App Store and Android on Google Play.</li>
                            </ul>
                        </li>
                        <!-- Section 8 -->
                        <li>
                            <h3 class="accordion__title">When can I find the manual for Smart Teddy?</h3>
                            <ul class="accordion__items">
                                <li class="accordion__item">The manual is available on our site or in the app, and a paper copy is provided along with your Teddy.</li>
                            </ul>
                        </li>
                        <!-- Section 9 -->
                        <li>
                            <h3 class="accordion__title">My Teddy is taking a long time to connect or the app is freezing up while it tries to connect</h3>
                            <ul class="accordion__items">
                                <li class="accordion__item">Turn off your Teddy and close the application (just going back to your home screen won't be enough—you need to close/swipe off the application in your multitasking menu).</li>
                                <li class="accordion__item">Wait for one minute and then turn your Teddy back on.</li>
                                <li class="accordion__item">Try to connect again.</li>
                                <li class="accordion__item">If a connection is not established, please send us a message at: hello@smartteddy.store.</li>
                            </ul>
                        </li>
                        <!-- Section 10 -->
                        <li>
                            <h3 class="accordion__title">My content is inaccessible/I can't click on the fairytales/the fairytales are all in grey</h3>
                            <ul class="accordion__items">
                                <li class="accordion__item">Try to update your Teddy.</li>
                                <li class="accordion__item">Open your mobile app and connect to the Teddy.</li>
                                <li class="accordion__item">In the My Smart Teddy app, open the Settings tab and connect your toy to your Wi-Fi network.</li>
                                <li class="accordion__item">If the yellow indicator light on the toy's electronics package has begun to blink steadily, that means the update has begun to download and you should wait for it to finish.</li>
                                <li class="accordion__item">If you have trouble downloading an update, send us a message at:
                                    <a href="mailto:hello@smartteddy.store.">hello@smartteddy.store.</a></li>
                            </ul>
                        </li>
                        <!-- Section 11 -->
                        <li>
                            <h3 class="accordion__title">If your Teddy won't turn on</h3>
                            <ul class="accordion__items">
                                <li class="accordion__item">Your Teddy's battery may have run out. Connect him to your charger and let him charge for at least an hour. A full charging cycle lasts six hours. If your toy still will not turn on, send us a message at: <a href="mailto:hello@smartteddy.store.">hello@smartteddy.store.</a></li>
                            </ul>
                        </li>
                        <!-- Section 12 -->
                        <li>
                            <h3 class="accordion__title">My Bluetooth isn't working.</h3>
                            <ul class="accordion__items">
                                <li class="accordion__item">Check your smartphone to make sure Bluetooth is turned on.</li>
                                <li class="accordion__item">If you are using Android, make sure geolocation is turned on.</li>
                                <li class="accordion__item">Restart your toy—turn it off and wait for one minute. </li>
                                <li class="accordion__item">Restart the application. Close the application (it won't be enough to go back to your main screen—you will have to swipe the application off in your multitasking menu) and then open it again a minute later.</li>
                                <li class="accordion__item">Try to find your Teddy.</li>
                                <p class="accordion__item-note">*You can connect to the Teddy only in My Smart Teddy app.</p>
                            </ul>
                        </li>
                        <!-- Section 13 -->
                        <li>
                            <h3 class="accordion__title">My WiFi isn't working</h3>
                            <ul class="accordion__items">
                                <li class="accordion__item">Open your phone's setting and make sure that your Wi-Fi network is visible and working.</li>
                                <li class="accordion__item">Restart your toy—turn it off and wait one minute.</li>
                                <li class="accordion__item">Restart the application.</li>
                                <li class="accordion__item">Close the application (it won't be enough to go back to your main screen—you will have to swipe the application off in your multitasking menu) and then open it again a minute later.</li>
                                <li class="accordion__item">Try to find your Teddy. Go to the Settings tab in the My Smart Teddy application and connect the toy to your Wi-Fi network.</li>
                                <li class="accordion__item">If the yellow indicator light on the toy's electronics package has begun to blink steadily, that means the update has begun to download and you should wait for it to finish.</li>
                                <p class="accordion__item-note">* If your home Wi-Fi network has both 5G and 2G indicators, then you should only connect to the 2G since the Teddy cannot see or use 5G Wi-Fi networks.</p>
                            </ul>
                        </li>
                        <!-- Section 14 -->
                        <li>
                            <h3 class="accordion__title">How do I update my Teddy?</h3>
                            <ul class="accordion__items">
                                <li class="accordion__item">Open the mobile application and connect to the toy.</li>
                                <li class="accordion__item">In the Smart Teddy app, go to the Settings tab and connect the toy to your Wi-Fi network.</li>
                                <li class="accordion__item">If the yellow indicator on the toy's electronics package has begun to blink steadily, the process of downloading the update has begun, and a "Smart Teddy is Updating" bar will appear in the mobile app. Please wait for it to finish before resuming play. *Updating may take some time. This depends on how long the device has not been connected to a Wi-Fi network, as well as your internet speed.</li>
                                <li class="accordion__item">Feel free to close the Smart Teddy app and use your phone as usual during the updating process.</li>
                                <li class="accordion__item">After it is first connected to your Wi-Fi network, the Teddy will update automatically if he is within a radius of that network.</li>
                            </ul>
                        </li>
                        <!-- Section 15 -->
                        <li>
                            <h3 class="accordion__title">What should I do if…</h3>
                            <ul class="accordion__items">
                                <li class="accordion__item">…the yellow indicator light is blinking, even when the toy is closed off/the audio playback is freezing/ the speakers are crackling/ touching a paw doesn't do anything. We are very sorry to say that your Smart Teddy needs some repairs. Please contact us at: <a href="mailto:hello@smartteddy.store.">hello@smartteddy.store.</a></li>
                            </ul>
                        </li>
                        <!-- Section 16 -->
                        <li>
                            <h3 class="accordion__title">Can Smart Teddy hear what people are saying and answer them?</h3>
                            <ul class="accordion__items">
                                <li class="accordion__item">The toy doesn't have a microphone, so he can't hear what you're saying. To answer, Smart Teddy needs your help. Choose an answer, and Teddy will say it out loud.</li>
                                <li class="accordion__item">The Teddy reacts independently to the interactive cards—when a child places a paw on a card, the bear will say the corresponding phrases.</li>
                            </ul>
                        </li>
                        <!-- Section 17 -->
                        <li>
                            <h3 class="accordion__title">Can I upload my own fairytales to Smart Teddy?</h3>
                            <ul class="accordion__items">
                                <li class="accordion__item">That isn't possible yet. If you can't find your favorite fairytale in the library, please write to us; we consider any requests we receive.</li>
                            </ul>
                        </li>
                        <!-- Section 18 -->
                        <li>
                            <h3 class="accordion__title">Can I change my Smart Teddy's voice?</h3>
                            <ul class="accordion__items">
                                <li class="accordion__item">No, that isn't possible. All the phrases Teddy says were recorded by the same actor, so you might say that your little bear has his own personality. We don't currently plan on changing it.</li>
                            </ul>
                        </li>
                        <!-- Section 19 -->
                        <li>
                            <h3 class="accordion__title">Can I wash my toy?</h3>
                            <ul class="accordion__items">
                                <li class="accordion__item">You can carefully wipe the outside of your bear or send it out for dry-cleaning. Since your Teddy has an electronics package inside, it is not washable.</li>
                            </ul>
                        </li>
                        <!-- Section 20 -->
                        <li>
                            <h3 class="accordion__title">Can I take my Smart Teddy outside, or on a plane?</h3>
                            <ul class="accordion__items">
                                <li class="accordion__item">Of course, but remember that your Teddy's battery runs out faster in the cold. There will be no problem taking your Teddy on a plane since it has a special mode that deactivates its Bluetooth and Wi-Fi.</li>
                            </ul>
                        </li>
                        <!-- Section 21 -->
                        <li>
                            <h3 class="accordion__title">What kind of warranty does Smart Teddy have?</h3>
                            <ul class="accordion__items">
                                <li class="accordion__item">The standard warranty is 12 months. That means that we will replace your Teddy with a new one if anything happens—even if your dog chews on him!</li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
</main>
<?get_footer();?>