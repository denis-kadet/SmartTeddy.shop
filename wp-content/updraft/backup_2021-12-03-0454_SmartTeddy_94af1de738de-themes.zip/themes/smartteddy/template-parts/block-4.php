<section class="section section-4__wrap">
    <div class="container">
        <div class="">
            <div class="row block-4__wrap">
                <div class="col-lg-5 col-md-7">
                    <div class="block-4__img-wrap">
                        <span class="block-4__img"></span>
                        <h3 class="block-4__title">Happiness guaranteed:</h3>
                    </div>
                </div>
                <div class="col-lg-4 col-md-5">
                    <div class="block-4__number-inner">
                        <div class="block-4__number__wrap">
                            <div class="block-4__number-border">
                                <div class="block-4__number">
                                    <div class="block-4__number-1">30</div>

                                    <div class="block-4__number-2">day</div>
                                </div>
                            </div>
                            <p class="block-4__text">
                                no questions-asked money-back guarantee
                            </p>
                        </div>
                        <span class="block-4__img-mob"></span>
                        <div class="block-4__number__wrap">
                            <div class="block-4__number-border">
                                <div class="block-4__number">
                                    <div class="block-4__number-1">12</div>
                                    <div class="block-4__number-2">month</div>
                                </div>
                            </div>
                            <p class="block-4__text">
                                extented warranty
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-12">
                    <div class="block-4__btn-inner">
                        <a href="#" class="block-4__btn-link">
                            <div class="block-4__btn-wrap">
                                <div class="block-4__btn-text">Learn more</div>
                            </div>
                        </a>
                    </div>

                </div>
            </div>
        </div>
    </div>
</section>
