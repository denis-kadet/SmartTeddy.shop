<section class="section-7__bg">
    <div class="container">
        <div class="row block-7__wrap">
            <div class="col-lg-6 col-md-8 col-sm-12">
                <h3 class="block-7__title">Easy to use. Easy to love.</h3>
                <div class="block-7__text-wrap"><span class="block-7__text">Find out how to set up Smart
                                Teddy</span></div>

            </div>
            <div class="col-lg-6 col-md-4 col-sm-12">
                <div class="block-4__btn-inner">
                    <a href="#" class="block-4__btn-link">
                        <div class="block-4__btn-wrap">
                            <div class="block-4__btn-text">Learn more</div>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>