<?php
/**
 * Checkout Form
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/checkout/form-checkout.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 3.5.0
 */

if (!defined('ABSPATH')) {
    exit;
}
?>


<div class="container form__checkout-wrap">
    <div class="row">
        <div class="col-lg-12">
            <form name="checkout" method="post" class="checkout woocommerce-checkout form__checkout-wrap_mob"
                  action="<?php echo esc_url(wc_get_checkout_url()); ?>" enctype="multipart/form-data">

                <?php if ($checkout->get_checkout_fields()) : ?>

                    <?php do_action('woocommerce_checkout_before_customer_details'); ?>

                    <div id="customer_details">

                        <?php do_action('woocommerce_checkout_billing'); ?>


<!--                        --><?php //do_action('woocommerce_checkout_shipping'); ?>

                    </div>

                    <?php do_action('woocommerce_checkout_after_customer_details'); ?>

                <?php endif; ?>

                <?php do_action('woocommerce_checkout_before_order_review_heading'); ?>


                <?php do_action('woocommerce_checkout_before_order_review'); ?>



                <?php do_action('woocommerce_checkout_after_order_review'); ?>

            </form>
        </div>
    </div>
</div>




