<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package SmartTeddy
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">

	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<!--<div id="access" role="navigation">-->
<!--    --><?php //wp_nav_menu( [
//        'container_class' => 'menu-header',
//        'theme_location'  => 'primary'
//    ] ); ?>
<!--</div>-->
<header class="header">
    <div class="container">
        <div class="row">
            <div class="header__wrap col-lg-12">
                <div class="header__logo">
                    <a href="/" class="header__logo-link">
                        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/icons/logo__icon.svg" alt="">
                    </a>
                </div>
                <div class="header__inner">
                    <nav class="header__nav">
                        <ul class="header__nav-items">
                            <li class="header__nav-item">
                                <a href="/how-smart-teddy-works/" class="header__nav-link header__nav-link_active">How Smart Teddy
                                    works</a>
                            </li>
                            <li class="header__nav-item">
                                <a href="/payment-and-shipping/" class="header__nav-link">Payment and shipping</a>
                            </li>
                            <li class="header__nav-item">
                                <a href="/happiness-guaranteed/" class="header__nav-link">Happiness guaranteed</a>
                            </li>
                            <li class="header__nav-item">
                                <a href="/support/" class="header__nav-link">Support</a>
                            </li>
                        </ul>
                    </nav>
                    <div class="header__btn">
                        <a href="<?php echo esc_url( wc_get_cart_url() ); ?>" class="header__btn-link">Buy now</a>
                    </div>
                    <div class="header__nav-mobile">
                        <a href="#" class="nav__mobile-icon_link">
                            <span class="header__logo-burger"></span>
                        </a>
                    </div>
                </div>
                <nav class="mobile__nav">
                    <ul class="mobile__nav-items">
                        <li class="mobile__nav-item">
                            <a href="#" class="mobile__nav-link">About us</a>
                        </li>
                        <li class="mobile__nav-item">
                            <a href="#" class="mobile__nav-link">How Smart Teddy works</a>
                        </li>
                        <li class="mobile__nav-item">
                            <a href="#" class="mobile__nav-link">Payment and shipping</a>
                        </li>
                        <li class="mobile__nav-item">
                            <a href="#" class="mobile__nav-link">Happiness guaranteed</a>
                        </li>
                        <li class="mobile__nav-item">
                            <a href="#" class="mobile__nav-link">FAQ</a>
                        </li>
                    </ul>
                </nav>
            </div>

        </div>
    </div>
</header>
