<script type="text/javascript">
    jQuery(document).ready(function(){
        jQuery('.woocommerce_flexible_shipping_ups_surepost_surepost_services').closest('tr').toggle(true);
    });
</script>

