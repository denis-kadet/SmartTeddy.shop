<?php

namespace UpsFreeVendor\Ups\Entity;

class LabelStockSize
{
    /**
     * Only valid values are 6 or8
     *
     * @var string
     */
    public $Height;
    /**
     * Valid value is 4
     *
     * @var string
     */
    public $Width;
}
