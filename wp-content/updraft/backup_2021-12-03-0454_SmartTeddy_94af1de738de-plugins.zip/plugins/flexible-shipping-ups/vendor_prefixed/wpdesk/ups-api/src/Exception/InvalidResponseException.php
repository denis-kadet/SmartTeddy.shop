<?php

namespace UpsFreeVendor\Ups\Exception;

use Exception;
class InvalidResponseException extends \Exception
{
}
