<?php

namespace UpsFreeVendor\Ups\Exception;

use Exception;
class RequestException extends \Exception
{
}
