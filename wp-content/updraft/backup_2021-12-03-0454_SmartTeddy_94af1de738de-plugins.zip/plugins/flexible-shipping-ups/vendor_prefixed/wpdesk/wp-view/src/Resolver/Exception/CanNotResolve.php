<?php

namespace UpsFreeVendor\WPDesk\View\Resolver\Exception;

class CanNotResolve extends \RuntimeException
{
}
