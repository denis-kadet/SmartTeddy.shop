<?php

namespace UpsFreeVendor;

if (!\defined('ABSPATH')) {
    exit;
}
?>
<style>
	.wpdesk-tracker-test div {
		color: yellow !important;
	}
</style><?php 
