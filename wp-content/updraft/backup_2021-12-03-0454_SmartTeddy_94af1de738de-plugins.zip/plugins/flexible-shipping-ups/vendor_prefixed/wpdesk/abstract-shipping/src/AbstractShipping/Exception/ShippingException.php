<?php

/**
 * Shipping exception interface.
 *
 * @package WPDesk\AbstractShipping\Exception
 */
namespace UpsFreeVendor\WPDesk\AbstractShipping\Exception;

/**
 * Shipping exception interface.
 *
 * @package WPDesk\AbstractShipping\Exception
 */
interface ShippingException
{
}
