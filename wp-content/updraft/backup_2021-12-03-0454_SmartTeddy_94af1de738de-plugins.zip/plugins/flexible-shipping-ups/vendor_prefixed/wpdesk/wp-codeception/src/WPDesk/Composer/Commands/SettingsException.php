<?php

/**
 * Class SettingsException
 * @package WPDesk\Composer\Codeception\Commands
 */
namespace UpsFreeVendor\WPDesk\Composer\Codeception\Commands;

/**
 * Settings Exception.
 */
class SettingsException extends \RuntimeException
{
}
