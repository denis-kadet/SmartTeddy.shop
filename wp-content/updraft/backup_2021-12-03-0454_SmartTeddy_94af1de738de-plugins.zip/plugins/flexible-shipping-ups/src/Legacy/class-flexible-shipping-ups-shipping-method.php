<?php
/**
 * Legacy class.
 *
 * @package WP Desk UPS.
 */

/**
 * Legacy class for UPS PRO plugin.
 */
class Flexible_Shipping_UPS_Shipping_Method extends \WC_Shipping_Method {
}
